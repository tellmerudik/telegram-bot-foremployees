
# Telegram Bot Project

Этот проект создан для сбора данных сотрудников и записи их в Google Таблицу.

## Установка
1. Установите зависимости:
   ```
   pip install -r requirements.txt
   ```

2. Запустите бота:
   ```
   python bot.py
   ```
